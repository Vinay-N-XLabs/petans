ansible-playbook playbook.yaml -i hosts.ini
